# 00 — HƯỚNG DẪN CÀI ĐẶT & THỨ TỰ CHẠY

## Bộ file
| File | Dùng khi nào |
|---|---|
| 01-NIGHTLY-MASTER.md | Prompt chính, chạy mỗi đêm |
| 02-NIGHT0-INVENTORY.md | Chạy 1 lần để kiểm kê + phân tầng 12 project |
| 03-DIRECTION-PROPOSAL.md | Ban ngày, trước mỗi project mới, để bạn chọn hướng thiết kế |
| 04-INDEPENDENT-REVIEWER.md | Được gọi từ prompt chính, trong phiên/ngữ cảnh mới |
| 05-TEMPLATES.md | Mẫu file điều phối trong `docs/portfolio-ops/` |

Gợi ý vị trí trong repo: `docs/portfolio-ops/prompts/` cho 5 file này và `docs/portfolio-ops/`
cho các file mẫu (PROJECTS, STATE, ...). Nếu `docs/` đã có quy ước khác thì theo quy ước đó.

## Chuẩn bị (một lần, làm trước khi chạy bất cứ thứ gì)
1. **Bảo vệ main ở phía GitHub:** bật branch protection cho `main` (bắt buộc PR, cần 1 review,
   không cho push trực tiếp). Đây là lớp bảo vệ thật; lời dặn trong prompt không thay thế được.
2. **Token quyền tối thiểu** cho agent: chỉ tạo branch và PR trên repo cần thiết; không quyền admin,
   không quyền secrets. Với các repo project khác (nếu 11 project nằm ngoài repo này) cấp riêng từng repo.
3. Kiểm tra môi trường chạy có **Playwright/trình duyệt** (Factory dùng Playwright). Không có thì agent
   không thể xác minh giao diện và sẽ không dán READY.
4. **Preview cho demo:** mình chưa kiểm tra thư mục `.github/` của repo. Nếu bạn muốn xem demo bằng
   link (Pages/Netlify/Vercel preview), cần cấu hình riêng; chưa có thì demo xem local bằng lệnh
   agent ghi trong PR.
5. Tạo `docs/portfolio-ops/` với các file mẫu trong 05-TEMPLATES.md, điền PROJECTS.md.

## Thứ tự chạy
1. **Đêm 0:** dán prompt 02 → sáng duyệt INVENTORY.md, chốt phân tầng A/B/C.
2. **Chiều hôm đó:** chạy prompt 03 cho project đầu tiên → chọn hướng → tự commit `STATUS: APPROVED`.
3. **Đêm 1:** chạy prompt 01 với `MODE: DRY_RUN` → đọc kế hoạch, sửa prompt nếu lệch ý.
4. **Đêm 2 trở đi:** đổi `MODE: LIVE`. Chạy thử với project nhỏ nhất để đo thời gian thật, rồi chỉnh
   `MAX_NIGHT_HOURS` theo METRICS.md.
5. **Mỗi chiều:** chạy prompt 03 cho project kế tiếp (trước đêm nó được thi công).
6. **Mỗi sáng (15–20 phút):** mở REVIEW.md → xem ảnh + mở demo thật 1 lần → điền mục CẦN CHỦ REPO ĐIỀN
   → merge PR đạt / ghi FEEDBACK.md cho PR chưa đạt → điền cột "OWNER quyết định" ở METRICS.md.
7. **Cuối chu kỳ:** đêm portfolio-level (trang index, ẩn/gom Tầng C, nhất quán tên và thumbnail).

## Lịch chạy (nếu dùng GitHub Actions)
Cron dùng giờ UTC: 01:00 GMT+7 = `0 18 * * *`. Có thể trễ vài phút. Quy trình Factory (Playwright,
MetaGPT) khá nặng; nếu runner mặc định hết giờ hoặc thiếu tài nguyên thì chạy trên máy/runner riêng.

## Chỉ số nên xem sau 1–2 tuần
- Tỷ lệ PR được merge ngay / phải sửa / bị từ chối → nếu từ chối nhiều: chỉnh prompt 03 (hướng) và
  ghi FEEDBACK.md kỹ hơn.
- Giờ chạy thực tế vs MAX_NIGHT_HOURS → điều chỉnh quota.
- Số lần chạm MAX_FIX_ATTEMPTS → dấu hiệu bước nào của pipeline yếu.

## Những điều bạn KHÔNG nên giao cho agent
- Quyết định hướng thiết kế cuối cùng (gu của bạn).
- Vai trò thật, số liệu thật, phản hồi người dùng thật trong case study.
- Trả lời phỏng vấn: INTERVIEW-PACK chỉ là bản nháp, bạn phải tự hiểu và làm chủ từng câu.
