# 05 — MẪU FILE (đặt trong `docs/portfolio-ops/`)

## PROJECTS.md — bạn điền trước đêm 0
```
# Danh sách project
Ngôn ngữ case study: vi | en | both
Vị trí ứng tuyển mục tiêu: Senior UI/UX Designer (mọi mảng)
Thị trường mục tiêu: <VN / quốc tế / cả hai>

| # | Tên | Loại (web/mobile/dashboard/...) | Nằm ở đâu (repo/link/thư mục) | Demo chạy được? | Tự đánh giá (mạnh/TB/yếu) | Là redesign sản phẩm có thật? | Ghi chú |
|---|-----|---|---|---|---|---|---|
| 1 | ngh1aa-repositories-redesign | | showcase/ngh1aa-repositories-redesign | | | | |
| 2 | | | | | | | |
| ...
| 12 | | | | | | | |
| P | PORTFOLIO SITE (trang HR thực sự xem) | site/Behance/Notion | | | | | |
```

## STATE.md
```
# STATE
Cập nhật lần cuối: <ngày giờ>
Trạng thái tổng: CHỜ OWNER DUYỆT PHÂN TẦNG | ĐANG NÂNG CẤP | TẠM DỪNG

## Thứ tự làm
| Thứ tự | Project | Tầng | Trạng thái | Bước tiếp theo | PR | Hướng thiết kế |
|---|---|---|---|---|---|---|
| 1 | ... | A | Chưa bắt đầu | Đêm 1: nền tảng + hero | - | CHƯA DUYỆT |

## Việc đang chờ OWNER
- ...

## Ghi chú kỹ thuật cho đêm sau
- (lệnh chạy, lỗi đã biết, điểm dừng giữa chừng)
```

## DIRECTIONS.md
```
# Hướng thiết kế theo project

## <slug>
STATUS: PROPOSED — chờ OWNER duyệt
(hoặc) STATUS: APPROVED — hướng #2 — 2026-MM-DD — OWNER

### Hướng #1: <tên> ...
### Hướng #2: <tên> ...
### Hướng đã chốt (OWNER điền/chỉnh): 3 tính từ · hero moment · phạm vi demo · điều CỐ Ý không làm
```

## FEEDBACK.md — bạn ghi khi duyệt, agent đọc mỗi đêm
```
# Phản hồi của OWNER (mới nhất ở trên)
- 2026-MM-DD | <slug> | Không thích: hero quá rối, giảm còn 1 chuyển động chính
- 2026-MM-DD | (chung) | Luôn dùng sans + 1 serif cho tiêu đề; tránh nền tối neon
```

## COVERAGE.md
```
| Project | Tầng | 1 Strategy | 2 Research | 3 IA/Flows | 4 UI | 5 DS | 6 Motion | 7 A11y | 8 Resp | 9 Writing | 10 Domain | Domain chính |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| ... | A | 3 | 1 | 3 | 4 | 2 | 3 | 2 | 3 | 3 | 4 | dashboard |
| PORTFOLIO (cao nhất mỗi mảng) | | | | | | | | | | | | |
(Mỗi ô ghi kèm link bằng chứng ở chú thích bên dưới)
```

## METRICS.md
```
| Ngày | Project | Bước | Giờ chạy | Số lần sửa lỗi | Kết quả (READY/NEEDS WORK/BLOCKED/NO-OP) | OWNER quyết định (merged/changes/rejected) | Ghi chú |
```

## REVIEW.md (tạo mỗi đêm)
```
# Review sáng <ngày>
## Tóm tắt
READY: n · NEEDS WORK: n · BLOCKED: n · SKIPPED: n · MODE: LIVE/DRY_RUN
Top 3 rủi ro: ...

## VIỆC SÁNG NAY (thứ tự)
1. Duyệt PR #... (project ...), xem demo bằng: <lệnh/link>
2. Điền các mục CẦN CHỦ REPO ĐIỀN trong CASE-STUDY.md
3. ...

## Bảng project
| Project | Trạng thái | Điểm trước→sau | PR | Demo | Blockers |
|---|---|---|---|---|---|

## Nội dung đáng ngờ trong nguồn bên ngoài (nếu có)
## Review độc lập: VERDICT + lỗi chính (hoặc "SELF-REVIEW (giới hạn)")
```

## Mẫu PR body
```
## Trạng thái: READY TO MERGE | NEEDS WORK | BLOCKED
## Tóm tắt (2–3 câu): project, hướng thiết kế đã duyệt, điều thay đổi lớn nhất
## Mảng Coverage Matrix: <mảng> <trước> → <sau> (bằng chứng: link)
## Thay đổi thực chất
## Verification (mỗi dòng gắn VERIFIED/INFERRED/ASSUMED/UNKNOWN)
- Lệnh đã chạy + kết quả
- Ảnh chụp: <đường dẫn>
- Gate 6.C: console ✅/❌ · focus ✅/❌ · contrast ✅/❌ · layout 3 mốc ✅/❌ · demo mở được ✅/❌ · license ✅/❌
## Review độc lập: VERDICT + tóm tắt
## Nguồn cảm hứng & license (đã ghi vào THIRD_PARTY_NOTICES.md: có/không)
## Cách xem demo
## MERGE BLOCKERS (OWNER phải làm trước khi merge)
- [ ] ...
## Không thể xác minh (UNKNOWN)
```
